Usage:

PhobosDecryptor [-all] [-r] [-d] [<PATH1>] [<PATH2>] ... [<PATHN>]

-all - Scan all fixed disks.
<PATH1>, <PATH2>, ... <PATHN> - paths to scan.

-r - Replace existing files.
-d - Delete encrypted files and ransom notes.
